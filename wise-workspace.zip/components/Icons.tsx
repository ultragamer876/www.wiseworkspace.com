
import React from 'react';

interface IconProps {
  className?: string;
}

export const DocumentIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
  </svg>
);

export const CheckCircleIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

export const InformationCircleIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M11.25 11.25l.041-.02a.75.75 0 011.063.852l-.708 2.836a.75.75 0 001.063.853l.041-.021M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9-3.75h.008v.008H12V8.25z" />
  </svg>
);

export const UploadCloudIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 16.5V9.75m0 0l3 3m-3-3l-3 3M6.75 19.5a4.5 4.5 0 01-1.41-8.775 5.25 5.25 0 0110.338-2.32 5.75 5.75 0 01-1.736 9.354M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

export const ShieldCheckIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12c0 1.268-.63 2.39-1.593 3.068M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9 6.75h.008v.008H12v-.008z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" transform="scale(0.8) translate(3 3)" /> {/* Simplified: Reused CheckCircle for inner part, adjusted */}
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 21.75c3.036 0 5.5-2.464 5.5-5.5V6.75a.75.75 0 00-1.5 0v9.5c0 2.21-1.79 4-4 4s-4-1.79-4-4v-9.5a.75.75 0 00-1.5 0v9.5c0 3.036 2.464 5.5 5.5 5.5z" /> {/* Outer shield part */}
  </svg>
);
// Note: A more accurate ShieldCheckIcon would involve a more complex SVG path.
// The ShieldCheckIcon above is a simplified representation.
// For a production app, you'd use a more standard icon library or a more detailed SVG.
// Corrected ShieldCheckIcon
export const CorrectedShieldCheckIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
    <path fillRule="evenodd" d="M12 2.25c.917 0 1.716.438 2.286 1.132L16.5 5.491c.374.459.407.804.407 1.159 0 .714-.363 1.181-.971 1.181h-.915v4.336c0 .714-.363 1.181-.971 1.181h-2.09c-.608 0-.971-.467-.971-1.181V7.831h-.915c-.608 0-.971-.467-.971-1.181 0-.355.033-.7.407-1.159l2.214-2.109A3.152 3.152 0 0112 2.25zm0 1.5a1.652 1.652 0 00-1.159.491L8.627 6.351c-.223.276-.243.482-.243.698 0 .429.218.709.583.709h.915v4.336c0 .429.218.709.583.709h2.09c.365 0 .583-.28.583-.709V7.758h.915c.365 0 .583-.28.583-.709 0-.216-.02-.422-.243-.698l-2.214-2.109A1.652 1.652 0 0012 3.75zm-.811 7.565H9.75V8.989h1.439v2.326zm2.062 0h-1.439V8.989h1.439v2.326zM5.897 6.36C5.302 7.145 5.25 7.833 5.25 8.625v6.75c0 2.044 1.512 3.75 3.375 3.75h6.75c1.863 0 3.375-1.706 3.375-3.75v-6.75c0-.792-.052-1.48-.647-2.265l-1.125 1.058c.26.44.286.767.286 1.207v6.75c0 1.24-.908 2.25-2.035 2.25h-6.75c-1.127 0-2.035-1.01-2.035-2.25v-6.75c0-.44.025-.767.286-1.207L5.897 6.36z" clipRule="evenodd" />
    <path d="M10.515 10.642l1.028 1.028 2.485-2.485a.75.75 0 111.06 1.06l-3 3a.75.75 0 01-1.06 0l-1.5-1.5a.75.75 0 111.06-1.06l.922.922z" />
  </svg>
);

// Replace ShieldCheckIcon with CorrectedShieldCheckIcon in ServiceCard if you prefer the more detailed one.
// For simplicity, the current implementation uses the initially provided ShieldCheckIcon.
// I will use the simpler one for now to avoid major visual divergence if you already liked the first pass.
// If you want the more detailed one, you can swap it in ServiceCard.tsx.
