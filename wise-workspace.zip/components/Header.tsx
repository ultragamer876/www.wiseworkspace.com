
import React from 'react';

export const Header: React.FC = () => {
  return (
    <header className="w-full max-w-5xl text-center py-6">
      <h1 className="text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-sky-400 via-cyan-300 to-teal-400">
        Wise Workspace
      </h1>
      <p className="mt-2 text-lg text-slate-300">Your Partner for Quality Online Services</p>
    </header>
  );
};
