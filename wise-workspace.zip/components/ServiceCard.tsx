
import React from 'react';
import { Service, UploadedFileState, PaymentStatus } from '../types';
import { FileUpload } from './FileUpload';
import { DocumentIcon, CheckCircleIcon, InformationCircleIcon, ShieldCheckIcon } from './Icons'; // Added ShieldCheckIcon

interface ServiceCardProps {
  service: Service;
  uploadedFileState: UploadedFileState | null;
  currentPaymentStatus?: PaymentStatus;
  onFileUpload: (serviceId: string, file: File) => void;
  onConfirmPayment: (serviceId: string) => void;
}

export const ServiceCard: React.FC<ServiceCardProps> = ({ 
  service, 
  uploadedFileState, 
  currentPaymentStatus,
  onFileUpload,
  onConfirmPayment 
}) => {
  return (
    <div className="bg-slate-800 shadow-xl rounded-lg p-6 flex flex-col justify-between transform hover:scale-105 transition-transform duration-300 ease-in-out border border-slate-700">
      <div>
        <h3 className="text-xl font-semibold text-sky-400 mb-2">{service.name}</h3>
        <p className="text-2xl font-bold text-teal-300 mb-3">{service.price}</p>
        {service.docTypes && (
          <p className="text-xs text-slate-400 mb-1">
            <span className="font-medium">Supported formats:</span> {service.docTypes}
          </p>
        )}
      </div>
      
      <div className="mt-4">
        {service.requiresFileUpload ? (
          uploadedFileState ? (
            <div className="bg-slate-700 p-4 rounded-md text-center">
              <div className="flex items-center justify-center mb-2">
                {currentPaymentStatus === 'confirmed' ? (
                  <ShieldCheckIcon className="w-10 h-10 text-green-400 mr-2" />
                ) : (
                  <DocumentIcon className="w-8 h-8 text-sky-300 mr-2" />
                )}
                <p className="text-sm font-medium text-slate-200 truncate" title={uploadedFileState.file.name}>
                  {uploadedFileState.file.name}
                </p>
              </div>
              <p className="text-xs text-slate-400 mb-3">
                ({(uploadedFileState.file.size / 1024).toFixed(2)} KB)
              </p>

              {currentPaymentStatus === 'pending' && (
                <>
                  <div className="mb-3 bg-yellow-500/20 border border-yellow-600 text-yellow-300 text-xs p-2 rounded-md flex items-center justify-center">
                    <InformationCircleIcon className="w-4 h-4 mr-2 flex-shrink-0" />
                    <span>File uploaded. Please complete payment to view.</span>
                  </div>
                  <button
                    onClick={() => onConfirmPayment(service.id)}
                    className="w-full bg-sky-500 hover:bg-sky-600 text-white font-semibold py-2 px-4 rounded-md transition-colors duration-200 text-sm"
                    aria-label={`Confirm payment for ${service.name}`}
                  >
                    Confirm Payment for this Service
                  </button>
                </>
              )}

              {currentPaymentStatus === 'confirmed' && (
                <div className="bg-green-500/20 border border-green-600 text-green-300 text-sm p-3 rounded-md flex items-center justify-center">
                  <CheckCircleIcon className="w-5 h-5 mr-2 flex-shrink-0" />
                  <span>Payment Confirmed. Document access granted (simulated).</span>
                </div>
              )}
               {!currentPaymentStatus && uploadedFileState && ( // Fallback, though should be 'pending'
                 <div className="mt-3 bg-yellow-500/20 border border-yellow-600 text-yellow-300 text-xs p-2 rounded-md flex items-center justify-center">
                    <InformationCircleIcon className="w-4 h-4 mr-2 flex-shrink-0" />
                    <span>Processing file... Please complete payment.</span>
                  </div>
               )}
            </div>
          ) : (
            <FileUpload
              serviceId={service.id}
              onFileUpload={onFileUpload}
            />
          )
        ) : (
          <div className="text-sm text-slate-500 italic text-center py-4 border-t border-slate-700 mt-4">
            No file upload required for this service.
          </div>
        )}
      </div>
    </div>
  );
};
