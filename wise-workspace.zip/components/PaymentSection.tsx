import React from 'react';
import { PAYMENT_METHODS, PAYMENT_INSTRUCTION_NUMBER } from '../constants';
import { PaymentMethod } from '../types';

export const PaymentSection: React.FC = () => {
  const handlePaymentMethodClick = (deepLink: string) => {
    window.location.href = deepLink;
  };

  return (
    <section id="payment" className="bg-slate-800 shadow-xl rounded-lg p-6 sm:p-8 border border-slate-700">
      <h2 className="text-3xl font-bold text-center mb-8 text-sky-400">Payment Method</h2>
      <div className="flex flex-col sm:flex-row justify-center items-center gap-6 sm:gap-10 mb-8">
        {PAYMENT_METHODS.map((method: PaymentMethod) => (
          <button
            key={method.name}
            onClick={() => handlePaymentMethodClick(method.deepLink)}
            className="flex flex-row items-center justify-center p-4 bg-slate-700 rounded-lg shadow-md hover:bg-slate-600 transition-all duration-300 ease-in-out w-full sm:w-auto min-w-[200px] transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:ring-opacity-50"
            aria-label={`Pay with ${method.name}`}
          >
            <img 
              src={method.logoUrl} 
              alt={`${method.name} logo`} 
              className="h-8 sm:h-10 object-contain mr-3" // Adjusted size and added right margin
            />
            <span className="text-lg font-semibold text-slate-200">{method.name}</span>
          </button>
        ))}
      </div>
      <div className="text-center bg-slate-700/50 p-4 rounded-md border border-slate-600">
        <p className="text-lg text-slate-200">
          Please send the money to this number:
        </p>
        <p className="text-2xl font-bold text-teal-300 mt-1 tracking-wider">
          {PAYMENT_INSTRUCTION_NUMBER}
        </p>
        <p className="text-xs text-slate-400 mt-2">
          Ensure you are using an official app for {PAYMENT_METHODS.map(m => m.name).join(' or ')}.
        </p>
      </div>
    </section>
  );
};