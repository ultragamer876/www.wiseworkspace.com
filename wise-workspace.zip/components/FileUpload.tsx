
import React, { useState, useCallback, useRef } from 'react';
import { ACCEPTED_FILE_TYPES } from '../constants';
import { UploadCloudIcon } from './Icons';

interface FileUploadProps {
  serviceId: string;
  docTypes?: string;
  onFileUpload: (serviceId: string, file: File) => void;
}

export const FileUpload: React.FC<FileUploadProps> = ({ serviceId, onFileUpload }) => {
  const [dragging, setDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0]) {
      onFileUpload(serviceId, event.target.files[0]);
    }
  }, [serviceId, onFileUpload]);

  const handleDragEnter = useCallback((event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    event.stopPropagation();
    setDragging(true);
  }, []);

  const handleDragLeave = useCallback((event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    event.stopPropagation();
    setDragging(false);
  }, []);

  const handleDragOver = useCallback((event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    event.stopPropagation();
  }, []);

  const handleDrop = useCallback((event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    event.stopPropagation();
    setDragging(false);
    if (event.dataTransfer.files && event.dataTransfer.files[0]) {
      onFileUpload(serviceId, event.dataTransfer.files[0]);
      // Clear the dataTransfer files to prevent issues if the same file is dropped again
      event.dataTransfer.clearData();
    }
  }, [serviceId, onFileUpload]);
  
  const handleClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div 
      className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors duration-200 ease-in-out
                  ${dragging ? 'border-sky-400 bg-slate-700' : 'border-slate-600 hover:border-sky-500 hover:bg-slate-700/50'}`}
      onDragEnter={handleDragEnter}
      onDragLeave={handleDragLeave}
      onDragOver={handleDragOver}
      onDrop={handleDrop}
      onClick={handleClick}
    >
      <input
        type="file"
        ref={fileInputRef}
        className="hidden"
        accept={ACCEPTED_FILE_TYPES}
        onChange={handleFileChange}
      />
      <UploadCloudIcon className="w-10 h-10 mx-auto text-slate-400 mb-2 group-hover:text-sky-400 transition-colors" />
      <p className="text-sm text-slate-300">
        <span className="font-semibold text-sky-400">Click to upload</span> or drag and drop
      </p>
      <p className="text-xs text-slate-500 mt-1">Max file size: 10MB</p>
    </div>
  );
};
