export interface Service {
  id: string;
  name: string;
  price: string;
  docTypes?: string; // e.g., "Word/PowerPoint - PDF - PNG"
  requiresFileUpload: boolean;
}

export enum PaymentMethodType {
  FASTPAY = 'FastPay',
  FIB = 'FIB', // First Iraqi Bank
}

export interface PaymentMethod {
  name: PaymentMethodType;
  logoUrl: string;
  deepLink: string;
}

export interface UploadedFileState {
  file: File;
  previewUrl?: string; // For potential image previews, though not primary focus
}

export type PaymentStatus = 'pending' | 'confirmed';
