
import { Service, PaymentMethod, PaymentMethodType } from './types';

export const SERVICES: Service[] = [
  { 
    id: 'autocad', 
    name: 'AutoCAD (2D & 3D)', 
    price: '40,000 IQD', 
    docTypes: '.dwg, .dxf, .pdf', // Added common CAD formats and PDF
    requiresFileUpload: true // Changed from false to true
  },
  { 
    id: 'academic_report', 
    name: 'Academic Report', 
    price: '35,000 IQD', 
    docTypes: 'Word/PowerPoint - PDF - PNG', 
    requiresFileUpload: true 
  },
  { 
    id: 'academic_seminar', 
    name: 'Academic Seminar', 
    price: '30,000 IQD', 
    docTypes: 'Word/PowerPoint - PDF - PNG', 
    requiresFileUpload: true 
  },
  { 
    id: 'data_entry', 
    name: 'Data Entry', 
    price: '25,000 IQD', 
    docTypes: 'Word/PowerPoint - PDF - PNG', 
    requiresFileUpload: true 
  },
  { 
    id: 'cv', 
    name: 'CV (Curriculum Vitae)', 
    price: '10,000 IQD', 
    docTypes: 'Word/PowerPoint - PDF - PNG', 
    requiresFileUpload: true 
  },
  { 
    id: 'translation', 
    name: 'Translation (Eng to Krd)', 
    price: '1,000 IQD / page', 
    docTypes: 'Word/PowerPoint - PDF - PNG', 
    requiresFileUpload: true 
  },
];

export const PAYMENT_METHODS: PaymentMethod[] = [
  {
    name: PaymentMethodType.FASTPAY,
    logoUrl: 'https://www.fast-pay.cash/image/catalog/logo/logo.png', // Official logo
    deepLink: 'fastpay://open', // Common deep link pattern
  },
  {
    name: PaymentMethodType.FIB,
    logoUrl: 'https://fib.iq/wp-content/uploads/2022/06/logo-blue.png', // Official logo
    deepLink: 'fib://', // Generic, actual FIB deep link might differ or not be publicly documented
  },
];

export const PAYMENT_INSTRUCTION_NUMBER = "0750 318 2003";

export const ACCEPTED_FILE_TYPES = ".doc,.docx,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,.ppt,.pptx,application/vnd.ms-powerpoint,application/vnd.openxmlformats-officedocument.presentationml.presentation,.pdf,image/png,application/pdf,.dwg,.dxf,image/vnd.dwg,image/vnd.dxf"; // Added DWG/DXF MIME types for broader compatibility
