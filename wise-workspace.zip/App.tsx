
import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { ServiceCard } from './components/ServiceCard';
import { PaymentSection } from './components/PaymentSection';
import { SERVICES } from './constants';
import { UploadedFileState, Service, PaymentStatus } from './types';

const App: React.FC = () => {
  const [uploadedFiles, setUploadedFiles] = useState<Record<string, UploadedFileState | null>>({});
  const [paymentStatuses, setPaymentStatuses] = useState<Record<string, PaymentStatus>>({});

  const handleFileUpload = useCallback((serviceId: string, file: File) => {
    setUploadedFiles(prevFiles => ({
      ...prevFiles,
      [serviceId]: { file },
    }));
    setPaymentStatuses(prevStatuses => ({
      ...prevStatuses,
      [serviceId]: 'pending', // Set payment status to pending on new upload
    }));
  }, []);

  const handlePaymentConfirmation = useCallback((serviceId: string) => {
    setPaymentStatuses(prevStatuses => ({
      ...prevStatuses,
      [serviceId]: 'confirmed',
    }));
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 text-gray-100 flex flex-col items-center p-4 sm:p-6 md:p-8">
      <Header />
      <main className="w-full max-w-5xl mt-8">
        <section id="services" className="mb-12">
          <h2 className="text-3xl font-bold text-center mb-8 text-sky-400">Our Services</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {SERVICES.map((service: Service) => (
              <ServiceCard
                key={service.id}
                service={service}
                uploadedFileState={uploadedFiles[service.id] || null}
                currentPaymentStatus={paymentStatuses[service.id]}
                onFileUpload={handleFileUpload}
                onConfirmPayment={handlePaymentConfirmation}
              />
            ))}
          </div>
        </section>
        <PaymentSection />
      </main>
      <footer className="w-full max-w-5xl mt-12 py-6 border-t border-slate-700 text-center">
        <p className="text-slate-400 text-sm">&copy; {new Date().getFullYear()} Wise Workspace. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default App;
